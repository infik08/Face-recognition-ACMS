
ygol - v2 2021-02-15 4:42pm
==============================

This dataset was exported via roboflow.ai on February 15, 2021 at 1:43 PM GMT

It includes 475 images.
Ygol are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


